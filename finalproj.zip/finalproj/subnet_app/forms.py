from django import forms

class SubnetForm(forms.Form):
    ip = forms.GenericIPAddressField(
        protocol="IPv4",
        label="IPv4 Address",
        help_text="Example: 192.168.1.10"
    )
    prefix = forms.IntegerField(
        min_value=0,
        max_value=32,
        label="Prefix (/CIDR)",
        help_text="Example: 24"
    )
