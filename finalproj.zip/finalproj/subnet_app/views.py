from django.shortcuts import render
from .forms import SubnetForm
from .utils import calculate_subnet

def subnet_calculator(request):
    result = None
    error = None

    if request.method == "POST":
        form = SubnetForm(request.POST)
        if form.is_valid():
            ip = form.cleaned_data["ip"]
            prefix = form.cleaned_data["prefix"]

            try:
                result = calculate_subnet(ip, prefix)
            except Exception as e:
                error = str(e)
        else:
            error = "Invalid input. Please enter a valid IP and prefix."
    else:
        form = SubnetForm()

    return render(request, "subnet_app/calculator.html", {
        "form": form,
        "result": result,
        "error": error,
    })
