import ipaddress

def calculate_subnet(ip, prefix):
    network = ipaddress.ip_network(f"{ip}/{prefix}", strict=False)

    if network.prefixlen < 31:
        hosts = list(network.hosts())
        first = hosts[0]
        last = hosts[-1]
        usable = len(hosts)
    else:
        first = last = None
        usable = 0

    return {
        "ip": ip,
        "prefix": prefix,
        "network": str(network.network_address),
        "broadcast": str(network.broadcast_address),
        "netmask": str(network.netmask),
        "hostmask": str(network.hostmask),
        "first_host": str(first) if first else "N/A",
        "last_host": str(last) if last else "N/A",
        "usable_hosts": usable,
    }
