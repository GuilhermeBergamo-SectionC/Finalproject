from django.contrib import admin
from django.urls import path
from subnet_app.views import subnet_calculator

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', subnet_calculator, name='calculator'),
]
